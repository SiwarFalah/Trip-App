package com.example.trip_application.utils;

public class Constant {

    public static final String EXTRA_AREA="EXTRA_AREA";
    public static final String EXTRA_TYPE="EXTRA_TYPE";
    public static final String EXTRA_PLACE_DATA="EXTRA_PLACE_DATA";
    public static final String EXTRA_PLACE_KEY="EXTRA_PLACE_KEY";
    public static final String PLACES_DB="places";
    public static final String COMMENTS_DB="comments";
    public static final int BEHAVIOR=0;
    public static final int COLOR_NUMBER=200;
    public static final int PICK_IMAGE=1;
}

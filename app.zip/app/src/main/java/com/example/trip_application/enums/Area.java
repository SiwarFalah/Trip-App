package com.example.trip_application.enums;

public enum Area {
    north,
    center,
    jerusalem,
    south
}

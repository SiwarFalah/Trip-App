package com.example.trip_application.enums;

public enum Type {
    beaches,
    trip,
    park
}

package com.example.trip_application.callbacks;

import android.location.Location;

import java.util.ArrayList;

public interface CallBack_Map {
    void addPlaces(ArrayList<Location> allLocations);
}
